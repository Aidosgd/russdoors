/* Fichier de langue franзaise de Shopkeeper pour MODx.
   ------------------------------------------------------------------------------
   Version de Shopkeeper : 0.8 / 0.9
   Version de la traduction : 0.1 Alpha

   Version de Shopkeeper : 0.9
   Version de la traduction : 0.1 Alpha

   Traduction franзaise : www.altipoint.ch
   
*/

var langTxt = new Array();

langTxt['delAll'] = "Vider le panier";
langTxt['select'] = "Yous avez choisi ;:";
langTxt['empty'] = "Vide";
langTxt['confirm'] = "Etes-vous certain ?";
langTxt['continue'] = "OK";
langTxt['yes'] = "Oui";
langTxt['cancel'] = "Annuler";
langTxt['cookieError'] = "Les cookies doivent кtre activйs dans le navigateur.";
langTxt['delete'] = "Supprimer";
langTxt['delGoods'] = "Retirer produits";
langTxt['goods'] = "produits";
langTxt['count'] = "Quantitй";
langTxt['sumTotal'] = "Total :";
langTxt['executeOrder'] = "Envoyer la commande";
langTxt['changeCount'] = "Modifier la quantitй";
langTxt['addedToCart'] = "Produit ajoutй au panier";
