<?php

//Language file for snippet Shopkeeper 1.0

$langTxt = array(
  "this" => "english",
  "confirm" => "Are you sure?",
  "noOrders" => "No orders are present",
  "noSelected" => "No items selected",
  "currency" => "Currency",
  "currencyDefault" => "USD",
  "plural" => array("items","item")
);


?>