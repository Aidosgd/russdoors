<?php

//Sprachdatei fur das Shopkeeper 1.0 Snippet

$langTxt = array(
  "this" => "german",
  "confirm" => "Sind Sie sicher?",
  "noOrders" => "Keine Bestellungen vorhanden",
  "noSelected" => "eine Artikel ausgewahlt",
  "currency" => "Wahrung",
  "currencyDefault" => "EUR",
  "plural" => array("artikel","element")
);


?>