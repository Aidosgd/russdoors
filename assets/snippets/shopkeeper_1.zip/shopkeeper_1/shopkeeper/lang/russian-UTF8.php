<?php

//Языковой файл для сниппета Shopkeeper 1.0

$langTxt = array(
  "this" => "russian",
  "confirm" => "Вы уверены?",
  "noOrders" => "Заказов нет",
  "noSelected" => "Товары не выбраны",
  "currency" => "Валюта",
  "currencyDefault" => "руб.",
  "sumTotal" => "Общая стоимость",
  "plural" => array("товар","товара","товаров")
);


?>