
//Language file for snippet Shopkeeper 0.8.x

var langTxt = new Array();

langTxt['delAll'] = "Warenkorb leeren";
langTxt['select'] = "Sie haben ausgew�hlt:";
langTxt['empty'] = "Leeren";
langTxt['confirm'] = "Sind Sie sicher?";
langTxt['continue'] = "OK";
langTxt['yes'] = "Ja";
langTxt['cancel'] = "Abbrechen";
langTxt['cookieError'] = "Ihr Browser sollte Cookies zulassen.";
langTxt['delete'] = "L�schen";
langTxt['delGoods'] = "Artikel entfernen";
langTxt['goods'] = "Artikel";
langTxt['count'] = "Menge";
langTxt['sumTotal'] = "Gesamtsumme :";
langTxt['executeOrder'] = "Bestellung abschicken";
langTxt['changeCount'] = "Menge �ndern";
langTxt['addedToCart'] = "Artikel wurde hinzugef�gt";
