<?php

//Fichier de langue fran�aise pour le snippet Shopkeeper 1.0 pour MODx.

$langTxt = array(
  "this" => "french",
  "confirm" => "Etes-vous certain ?",
  "noOrders" => "Aucune commande presente",
  "noSelected" => "Aucun produit selectionne",
  "currency" => "Devise",
  "currencyDefault" => "EUR",
  "plural" => array("articles","article")
);


?>