

var langTxt = new Array();

langTxt['delAll'] = "Warenkorb leeren";
langTxt['select'] = "Sie haben ausgewählt:";
langTxt['empty'] = "Leeren";
langTxt['confirm'] = "Sind Sie sicher?";
langTxt['continue'] = "OK";
langTxt['yes'] = "Ja";
langTxt['cancel'] = "Abbrechen";
langTxt['cookieError'] = "Ihr Browser sollte Cookies zulassen.";
langTxt['delete'] = "Löschen";
langTxt['delGoods'] = "Artikel entfernen";
langTxt['goods'] = "Artikel";
langTxt['count'] = "Menge";
langTxt['sumTotal'] = "Gesamtsumme :";
langTxt['executeOrder'] = "Bestellung abschicken";
langTxt['changeCount'] = "Menge ändern";
langTxt['addedToCart'] = "Artikel wurde hinzugefügt";
