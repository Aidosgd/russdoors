<?php

//Fichier de langue franзaise pour le snippet Shopkeeper 1.0 pour MODx.

$langTxt = array(
  "this" => "french",
  "confirm" => "Etes-vous certain ?",
  "noOrders" => "Aucune commande présente",
  "noSelected" => "Aucun produit sélectionné",
  "currency" => "Devise",
  "currencyDefault" => "EUR",
  "plural" => array("articles","article")
);


?>