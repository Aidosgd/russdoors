<?php

/*
Русский 
*/

$langTxt = array(
    "this" => 'russian',
    "noResult" => 'Ничего не найдено.',
    "next" => ' <a href="[+link+]">Следующая</a> ',
    "prev" => ' <a href="[+link+]">Предыдущая</a> '
);


?>