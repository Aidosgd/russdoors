<?php

//English

$langTxt = array(
    "this" => 'english',
    "noResult" => 'Nothing was found.',
    "next" => ' <a href="[+link+]">Next</a> ',
    "prev" => ' <a href="[+link+]">Previous</a> '
);


?>