<?php

return number_format($output,(floor($output) == $output ? 0 : 2),'.',' ');

?>