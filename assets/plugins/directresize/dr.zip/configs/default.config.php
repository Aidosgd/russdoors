<?
// Use the following syntax $param = 'value';
// You can use DIRECTRESIZE_PATH as full path to plugin folder  
?>