//loading image
var fileLoadingImage = "assets/plugins/directresize/libs/slimbox/images/loading.gif";		
//close image
var fileBottomNavCloseImage = "assets/plugins/directresize/libs/slimbox/images/closelabel.gif";
//next image
var nextLinkImage = "assets/plugins/directresize/libs/slimbox/images/nextlabel.gif";
//previous image
var previousLinkImage = "assets/plugins/directresize/libs/slimbox/images/prevlabel.gif";
//controls the speed of the image resizing in milliseconds
var resizeDuration = 500;
//resize transition effect
var resizeTransition = Fx.Transitions.sineInOut;
//the "Image" part from the text "Image 1 of 6"
var imageNrDesc = "Im1age";
//the separator "of" from the text "Image 1 of 6", you can change to / slash or whatever
var imageNrSep = "of";
//accelerator keys that goes to next picture, separate by commas
var nextKeys = new Array("n"," ");
//accelerator keys that goes to previous picture, separate by commas
var prevKeys = new Array("b");
//accelerator keys that close the lightbox, separate by commas
var closeKeys = new Array("c","x","q");
