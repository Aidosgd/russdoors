hs.restoreTitle = "Click to close image, click and drag to move. Use arrow keys for next and previous.";
hs.loadingText = "Loading...";
hs.loadingTitle = "Click to cancel";
hs.focusTitle = "Click to bring to front";
hs.fullExpandTitle = "Expand to actual size";