<?php

$_lang['lang'] = "ru";
$_lang['filesize_b'] = "�";
$_lang['filesize_Kb'] = "��";
$_lang['filesize_Mb'] = "��";
$_lang['filesize_Tb'] = "��";

?>