<?php
/*
 * Title: Language File
 * Purpose:
 *  Default English language file for DirectResize
*/
$_lang['lang'] = "en";
$_lang['filesize_b'] = "b";
$_lang['filesize_Kb'] = "Kb";
$_lang['filesize_Mb'] = "Mb";
$_lang['filesize_Tb'] = "Tb";
?>