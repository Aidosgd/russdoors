//loading image

var fileLoadingImage = "assets/plugins/directresize/libs/lightboxv2/images/loading.gif";		
//close image
var fileBottomNavCloseImage = "assets/plugins/directresize/libs/lightboxv2/images/closelabel.gif";
//next image
var nextLinkImage = "assets/plugins/directresize/libs/lightboxv2/images/nextlabel.gif";
//previous image
var previousLinkImage = "assets/plugins/directresize/libs/lightboxv2/images/prevlabel.gif";
//controls the speed of the image resizing (1=slowest and 10=fastest)
var resizeSpeed = 7;
//if you adjust the padding in the CSS, you will need to update this variable
var borderSize = 10;
//the "Image" part from the text "Image 1 of 6"
var imageNrDesc = "Image";
//the separator "of" from the text "Image 1 of 6", you can change to / slash or whatever
var imageNrSep = "of";
//accelerator keys that goes to next picture, separate by commas
var nextKeys = new Array("n"," ");
//accelerator keys that goes to previous picture, separate by commas
var prevKeys = new Array("b");
//accelerator keys that close the lightbox, separate by commas
var closeKeys = new Array("c","x","q");
